function validate(){
    var password=document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

    if (password != confirmPassword) { 
         document.getElementById("re-passwordError").innerHTML = "Password not matched";
        }  
    else if{
        document.getElementById("re-passwordError").innerHTML = "Password matched";
    }
        else{
            var form = document.getElementById("resetPassword");
            form.action = "Home.html";
            form.submit();
        }
        

}