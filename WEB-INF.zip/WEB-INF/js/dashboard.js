function Activate(){
    document.getElementById("activate").innerHTML = "Card Activated!";
}